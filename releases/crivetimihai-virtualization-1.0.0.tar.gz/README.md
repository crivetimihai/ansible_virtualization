Ansible Virtualization Collection
=================================

Sets up virtualization software:
- KVM
- VirtualBox
- VMware Workstation

Tested on:
----------

- CentOS 7
